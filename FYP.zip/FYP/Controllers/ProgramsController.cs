﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using FYP.Models;
using System;
using System.Data;
// using Microsoft.AspNetCore.Authorization;

namespace FYP.Controllers
{
    public class ProgramsController : Controller
    {
        // [Authorize(Roles = "user")]
        public IActionResult ProgramsList()
        {
            string sql = "SELECT Eventid, Eventname, CONVERT(VARCHAR, Eventdate, 106) As Eventdate, Eventstarttime, Eventendtime, Eventvenue FROM Events";
            DataTable dt = DBUtl.GetTable(sql);
            return View(dt.Rows);
        }

        public IActionResult ProgramsDetails(String id)
        {
            string sql = "SELECT Eventid, Eventname, CONVERT(DATETIME, Eventdate) As Eventdate, CONVERT(DATETIME, Eventstarttime) As Eventstarttime, CONVERT(DATETIME, Eventendtime) As Eventendtime, Eventvenue, Eventdescription FROM Events WHERE Eventid = '{0}'";
            string select = String.Format(sql, id);
            DataTable dt = DBUtl.GetTable(select);
            if (dt.Rows.Count == 1)
            {
                Events events = new Events
                {
                    Eventid = (int)dt.Rows[0]["Eventid"],
                    Eventname = dt.Rows[0]["Eventname"].ToString(),
                    Eventdate = (DateTime)dt.Rows[0]["Eventdate"],
                    Eventstarttime = (DateTime)dt.Rows[0]["Eventstarttime"],
                    Eventendtime = (DateTime)dt.Rows[0]["Eventendtime"],
                    Eventvenue = dt.Rows[0]["Eventvenue"].ToString(),
                    Eventdescription = dt.Rows[0]["Eventdescription"].ToString()
                };
                return View(events);
            }
            return View();
        }

        public IActionResult Programs_Details(String id)
        {
            string sql = "SELECT Eventid, Eventname, CONVERT(DATETIME, Eventdate) As Eventdate, CONVERT(DATETIME, Eventstarttime) As Eventstarttime, CONVERT(DATETIME, Eventendtime) As Eventendtime, Eventvenue, Eventdescription FROM Events WHERE Eventid = '{0}'";
            string select = String.Format(sql, id);
            DataTable dt = DBUtl.GetTable(select);
            if (dt.Rows.Count == 1)
            {
                Events events = new Events
                {
                    Eventid = (int)dt.Rows[0]["Eventid"],
                    Eventname = dt.Rows[0]["Eventname"].ToString(),
                    Eventdate = (DateTime)dt.Rows[0]["Eventdate"],
                    Eventstarttime = (DateTime)dt.Rows[0]["Eventstarttime"],
                    Eventendtime = (DateTime)dt.Rows[0]["Eventendtime"],
                    Eventvenue = dt.Rows[0]["Eventvenue"].ToString(),
                    Eventdescription = dt.Rows[0]["Eventdescription"].ToString()
                };
                return View(events);
            }
            return View();
        }

        // [Authorize(Roles = "admin")]
        public IActionResult ProgramsAdd()
        {
            return View();
        }

        public IActionResult ProgramsAddPost()
        {
            IFormCollection form = HttpContext.Request.Form;
            string eventname = form["ename"].ToString().Trim();
            string eventdate = form["edate"].ToString().Trim();
            string eventstarttime = form["estime"].ToString().Trim();
            string eventendtime = form["eetime"].ToString().Trim();
            string eventvenue = form["evenue"].ToString().Trim();
            string eventdescription = form["edescription"].ToString().Trim();

            string sql = @"INSERT INTO Events(Eventname, Eventdate, Eventstarttime, Eventendtime, Eventvenue, Eventdescription) 
                        VALUES('{0}', '{1}', '{2}', '{3}', '{4}', '{5}')";
            string insert = String.Format(sql, eventname, eventdate, eventstarttime, eventendtime, eventvenue, eventdescription);
            int res = DBUtl.ExecSQL(insert);
            if (res == 1)
            {
                TempData["Message"] = "Event Successfully Uploaded";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("ProgramsEditList");
        }
        
        // [Authorize(Roles = "admin")]
        public IActionResult ProgramsEditList()
        {
            string sql = "SELECT Eventid, Eventname, CONVERT(VARCHAR, Eventdate, 106) As Eventdate, Eventstarttime, Eventendtime, Eventvenue FROM Events";
            DataTable dt = DBUtl.GetTable(sql);
            return View(dt.Rows);
        }

        public IActionResult ProgramsEdit(String id)
        {
            string sql = "SELECT Eventid, Eventname, CONVERT(DATETIME, Eventdate) As Eventdate, CONVERT(DATETIME, Eventstarttime) As Eventstarttime, CONVERT(DATETIME, Eventendtime) As Eventendtime, Eventvenue, Eventdescription FROM Events WHERE Eventid = '{0}'";
            string select = String.Format(sql, id);
            DataTable dt = DBUtl.GetTable(select);
            if (dt.Rows.Count == 1)
            {
                Events events = new Events
                {
                    Eventid = (int)dt.Rows[0]["Eventid"],
                    Eventname = dt.Rows[0]["Eventname"].ToString(),
                    Eventdate = (DateTime)dt.Rows[0]["Eventdate"],
                    Eventstarttime = (DateTime)dt.Rows[0]["Eventstarttime"],
                    Eventendtime = (DateTime)dt.Rows[0]["Eventendtime"],
                    Eventvenue = dt.Rows[0]["Eventvenue"].ToString(),
                    Eventdescription = dt.Rows[0]["Eventdescription"].ToString()
                };
                return View(events);
            }
            return View();
        }

        public IActionResult ProgramsEditPost(String id)
        {
            IFormCollection form = HttpContext.Request.Form;
            string eventid = form["eid"].ToString().Trim();
            string eventname = form["ename"].ToString().Trim();
            string eventdate = form["edate"].ToString().Trim();
            string eventstarttime = form["estime"].ToString().Trim();
            string eventendtime = form["eetime"].ToString().Trim();
            string eventvenue = form["evenue"].ToString().Trim();
            string eventdescription = form["edescription"].ToString().Trim();

            string sql = @"UPDATE Events SET Eventname = '{1}', Eventdate = '{2}', Eventstarttime = '{3}', Eventendtime = '{4}', Eventvenue = '{5}', Eventdescription = '{6}' WHERE Eventid = '{0}'";
            string update = String.Format(sql, eventid, eventname, eventdate, eventstarttime, eventendtime, eventvenue, eventdescription);
            int res = DBUtl.ExecSQL(update);
            if (res == 1)
            {
                TempData["Message"] = "Event Successfully Updated";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("ProgramsEditList");
        }
             
        public IActionResult ProgramsDelete(String id)
        {
            string sql = "DELETE FROM Events WHERE Eventid = '{0}'";
            string delete = String.Format(sql, id);
            int res = DBUtl.ExecSQL(delete);
            if (res == 1)
            {
                TempData["Message"] = "Event Successfully Deleted";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("ProgramsEditList");
        }

        public IActionResult AttendanceList()
        {
            string sql = "SELECT Attendance_ID, Status_Type, User_ID, Event_ID FROM Attendance";
            DataTable dt = DBUtl.GetTable(sql);
            return View(dt.Rows);
        }

        public IActionResult AddAttendance()
        {
            return View();
        }

        public IActionResult AddAttendancePost()
        {
            IFormCollection form = HttpContext.Request.Form;
            string Status_Type = form["Status_Type"].ToString().Trim();
            string User_ID = form["User_ID"].ToString().Trim();
            string Event_ID = form["Event_ID"].ToString().Trim();

            string sql = @"INSERT INTO Attendance(Status_Type, User_ID, Event_ID) 
                        VALUES('{0}', '{1}', '{2}')";
            string insert = String.Format(sql, Status_Type, User_ID, Event_ID);
            int res = DBUtl.ExecSQL(insert);
            if (res == 1)
            {
                TempData["Message"] = "Attendance Successfully Uploaded";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("AttendanceList");
        }

        public IActionResult Register(String id)
        {
            string sql = @"INSERT INTO Attendance (Status_Type, User_ID, Event_ID) SELECT 'Register', Users.User_ID, Events.Eventid FROM Users, Events WHERE Events.Eventid = '{0}'";
            int res = DBUtl.ExecSQL(sql, id);
            if (res == 1)
            {
                TempData["Message"] = "You have successfully registered for the event";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("ProgramsList");
        }

        public IActionResult EditAttendance(String id)
        {
            string sql = "SELECT Attendance_ID, Status_Type, User_ID, Event_ID FROM Attendance WHERE Attendance_ID = '{0}'";
            string select = String.Format(sql, id);
            DataTable dt = DBUtl.GetTable(select);
            if (dt.Rows.Count == 1)
            {
                Attendance attendance = new Attendance
                {
                    Attendance_ID = (int)dt.Rows[0]["Attendance_ID"],
                    Status_Type = dt.Rows[0]["Status_Type"].ToString(),
                    User_ID = (int)dt.Rows[0]["User_ID"],
                    Event_ID = (int)dt.Rows[0]["Event_ID"]
                };
                return View(attendance);
            }
            return View();
        }

        public IActionResult EditAttendancePost(String id)
        {
            IFormCollection form = HttpContext.Request.Form;
            string Attendance_ID = form["Attendance_ID"].ToString().Trim();
            string Status_Type = form["Status_Type"].ToString().Trim();
            string User_ID = form["User_ID"].ToString().Trim();
            string Event_ID = form["Event_ID"].ToString().Trim();

            string sql = @"UPDATE Attendance SET Status_Type = '{1}', User_ID = '{2}', Event_ID = '{3}' WHERE Attendance_ID = '{0}'";
            string update = String.Format(sql, Attendance_ID, Status_Type, User_ID, Event_ID);
            int res = DBUtl.ExecSQL(update);
            if (res == 1)
            {
                TempData["Message"] = "Attendance Successfully Updated";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("AttendanceList");
        }

        public IActionResult Attend(String id)
        {
            string sql = @"UPDATE Attendance SET Status_Type = 'Attend', User_ID = Users.User_ID, Event_ID = Events.Eventid FROM Events, Users WHERE Events.Eventid = Attendance.Event_ID AND Users.User_ID = Attendance.User_ID";
            int res = DBUtl.ExecSQL(sql, id);
            if (res == 1)
            {
                TempData["Message"] = "Attendance Successful";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("ProgramsList");
        } 

        public IActionResult DeleteAttendance(String id)
        {
            string sql = "DELETE FROM Attendance WHERE Attendance_ID = '{0}'";
            string delete = String.Format(sql, id);
            int res = DBUtl.ExecSQL(delete);
            if (res == 1)
            {
                TempData["Message"] = "Attendance Successfully Deleted";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("AttendanceList");
        }

    }

}