﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using FYP.Models;
using System.Data;
using Microsoft.AspNetCore.Http;
using System.IO;
using Microsoft.AspNetCore.Hosting;

namespace FYP.Controllers
{
    public class UsersController : Controller
    {

        [Authorize]
        public IActionResult Main()
        {
            DataTable dt = DBUtl.GetTable("SELECT * FROM Users");
            return View(dt.Rows);
        }


        public IActionResult Display(int id)
        {
            string sql = String.Format(@"SELECT * FROM Users 
                                       WHERE User_ID = {0}", id);
            List<FYP.Models.Users> lstUser = DBUtl.GetList<FYP.Models.Users>(sql);
            if (lstUser.Count == 0)
            {
                TempData["Message"] = $"Users #{id} not found";
                TempData["MsgType"] = "warning";
                return RedirectToAction("Index");
            }
            else
            {
                // Get the FIRST element of the List
                FYP.Models.Users usr = lstUser[0];
                return View(usr);
            }
        }

        // To Present An Emtpy Form
        [HttpGet]
        public IActionResult Create()
        {
            return View("Create");
        }

        // To Handle Post Back Input Data 
        [HttpPost]
        public IActionResult Create(Users usr, IFormFile photo)
        {
            if (!ModelState.IsValid)
            {
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View(usr);
            }
            else
            {
                usr.PicFile = Path.GetFileName(photo.FileName);
                string fname = "Users/" + usr.PicFile;
                UploadFile(photo, fname);

                string sql = @"INSERT Users(  
                                            UserPw,  
                                            User_FirstName, 
                                            User_LastName, 
                                            User_Gender, 
                                            User_Date_of_Birth, 
                                            User_EmailAddress, 
                                            User_Type,
                                            User_ContactNumber) 

                           VALUES( HASHBYTES('SHA1', '{0}'), '{1}', '{2}', '{3}', '{4:yyyy-MM-dd}', '{5}', 'User', '{7}')";

                string insert =
                   String.Format(sql, 
                                          usr.User_Pw,
                                          usr.User_Type,
                                          usr.User_FirstName,
                                          usr.User_LastName,
                                          usr.User_Gender,
                                          usr.User_Date_of_Birth,
                                          usr.User_EmailAddress,
                                          usr.User_ContactNumber,
                                          usr.PicFile);

                if (DBUtl.ExecSQL(insert) == 1)
                {
                    TempData["Message"] = $"User #{usr.User_Type} created Successfully";
                    TempData["MsgType"] = "success";
                    return RedirectToAction("Index");
                }
                else
                {
                    ViewData["Message"] = DBUtl.DB_Message;
                    ViewData["MsgType"] = "danger";
                    return View(usr);
                }
            }
        }

        private void UploadFile(IFormFile ufile, string fname)
        {
            string fullpath = Path.Combine(_env.WebRootPath, fname);
            using (var fileStream = new FileStream(fullpath, FileMode.Create))
            {
                ufile.CopyToAsync(fileStream);
            }
        }

        private IWebHostEnvironment _env;
        public UsersController(IWebHostEnvironment environment)
        {
            _env = environment;
        }

       

        [AllowAnonymous]
        public IActionResult UserRegister()
        {
            return View();
        }


        [AllowAnonymous]
        [HttpPost]
        public IActionResult UserRegisterPost()
        {
            IFormCollection form = HttpContext.Request.Form;
            string User_EmailAddress = form["User_EmailAddress"].ToString().Trim();
            string User_Pw = form["User_Pw"].ToString().Trim();
            string User_FirstName = form["User_FirstName"].ToString().Trim();
            string User_LastName = form["User_LastName"].ToString().Trim();
            string User_Gender = form["User_Gender"].ToString().Trim();
            string User_Date_of_Birth = form["User_Date_of_Birth"].ToString().Trim();
            string User_ContactNumber = form["User_ContactNumber"].ToString().Trim();

            string sql = @"INSERT INTO Users(User_EmailAddress, User_Pw, User_FirstName, User_LastName, User_Gender, User_Date_of_Birth, User_ContactNumber) 
                        VALUES('{7}', HASHBYTES('SHA1', '{1}'), '{2}', '{3}', '{4}', '{5}', {6})";
            string insert = String.Format(sql, User_EmailAddress, User_Pw, User_FirstName, User_LastName, User_Gender, User_Date_of_Birth, User_ContactNumber);
            int res = DBUtl.ExecSQL(insert);
            if (res == 1)
            {
                TempData["Message"] = "User is Successfully Added";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("UserRegister");
        }


        public IActionResult DatePicker()
        {
            return View();
        }

        [HttpPost]
        public IActionResult DatePicker(IFormCollection form)
        {
            string User_Date_of_Birth = form["User_Date_of_Birth"].ToString().Trim();

            ViewData["Message"] = $"[{User_Date_of_Birth}]";
            ViewData["MsgType"] = "info";
            return View("UserRegister");
        }

        public IActionResult Download()
        {

            return View("DownloadMaterials");
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult MyAcct(int id)
        {
            string sql = "SELECT User_ID, User_Pw, User_Type, User_FirstName, User_LastName, User_Gender,  CONVERT(DATETIME, User_Date_of_Birth) As User_Date_of_Birth, User_ContactNumber, User_EmailAddress FROM Users WHERE User_ID = '{0}'";
            string select = String.Format(sql, id);
            DataTable dt = DBUtl.GetTable(select);
            if (dt.Rows.Count == 1)
            {
                Users user = new Users
                {
                    User_ID = (int)dt.Rows[0]["User_ID"],
                    User_Pw = dt.Rows[0]["User_Pw"].ToString(),
                    User_Type = dt.Rows[0]["User_Type"].ToString(),
                    User_FirstName = dt.Rows[0]["User_FirstName"].ToString(),
                    User_LastName = dt.Rows[0]["User_LastName"].ToString(),
                    User_Gender = dt.Rows[0]["User_Gender"].ToString(),
                    User_Date_of_Birth = (DateTime)dt.Rows[0]["User_Date_of_Birth"],
                    User_EmailAddress = dt.Rows[0]["User_EmailAddress"].ToString(),
                    User_ContactNumber = (int)dt.Rows[0]["User_ContactNumber"]

                };
                return View(user);
            }
            return View();
        }



        [AllowAnonymous]
        [HttpPost]
        public IActionResult MyAcctPost()
        {
            IFormCollection form = HttpContext.Request.Form;
            string User_EmailAddress = form["User_EmailAddress"].ToString().Trim();
            string User_Pw = form["User_Pw"].ToString().Trim();
            string User_FirstName = form["User_FirstName"].ToString().Trim();
            string User_LastName = form["User_LastName"].ToString().Trim();
            string User_Gender = form["User_Gender"].ToString().Trim();
            string User_Date_of_Birth = form["User_Date_of_Birth"].ToString().Trim();
            string User_ContactNumber = form["User_ContactNumber"].ToString().Trim();

            string sql = @"UPDATE Users SET User_Pw = HASHBYTES('SHA1', '{1}'), User_FirstName = '{3}', User_LastName = '{4}', User_Gender = '{5}', User_Date_of_Birth = '{6}', User_EmailAddress = '{7}', User_ContactNumber = {8} WHERE User_ID = {0}";
            string update = String.Format(sql, User_EmailAddress, User_Pw, User_FirstName, User_LastName, User_Gender, User_Date_of_Birth, User_ContactNumber);
            int res = DBUtl.ExecSQL(update);
            if (res == 1)
            {
                TempData["Message"] = "User Profile is Successfully Updated";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("Main");
        }

            public IActionResult DeleteAccount(String id)
            {
            string sql = "DELETE FROM Users WHERE User_ID = '{0}'";
            string delete = String.Format(sql, id);
            int res = DBUtl.ExecSQL(delete);
            if (res == 1)
            {
                TempData["Message"] = "Account Successfully Deleted";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("Main");
        }

    }
}