﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using FYP.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FYP.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Guest()
        {
            return View("Guest");
        }

        public IActionResult Login()
        {
            return View("UserLogin");
        }

        private const string LOGIN_SQL =
        @"SELECT * FROM Users 
            WHERE User_EmailAddress = '{0}' 
              AND User_Pw = HASHBYTES('SHA1', '{1}')";

        private const string LASTLOGIN_SQL =
            @"UPDATE Users SET LastLogin=GETDATE() WHERE User_EmailAddress='{0}'";

        private const string ROLE_COL = "User_Type";
        private const string NAME_COL = "User_FirstName";

        private const string REDIRECT_CNTR = "Home";
        private const string REDIRECT_ACTN = "Dashboard";

        private const string LOGIN_VIEW = "UserLogin";

        [AllowAnonymous] // Anyone can access the page
        [HttpGet]
        public IActionResult Login(string returnUrl = null)
        {
            TempData["ReturnUrl"] = returnUrl;
            return View(LOGIN_VIEW);
        }


        [AllowAnonymous]
        [HttpPost] // previous action will be [HttpGet](MUST WRITE IT)
        public IActionResult Login(UserLogin user)
        {
            if (!AuthenticateUser(user.User_EmailAddress, user.User_Pw,
                                  out ClaimsPrincipal principal))
            {
                ViewData["Message"] = "Incorrect User ID or Password";
                return View(LOGIN_VIEW);
            }
            else
            {
                HttpContext.SignInAsync(
                   CookieAuthenticationDefaults.AuthenticationScheme,
                   principal,
               new AuthenticationProperties
               {
                   IsPersistent = user.RememberMe
               });

                // Update the Last Login Timestamp of the User
                DBUtl.ExecSQL(LASTLOGIN_SQL, user.User_EmailAddress);

                if (TempData["returnUrl"] != null)
                {
                    string returnUrl = TempData["returnUrl"].ToString();
                    if (Url.IsLocalUrl(returnUrl))
                        return Redirect(returnUrl);
                }

                return RedirectToAction(REDIRECT_ACTN,REDIRECT_CNTR);
            }
        }

       
        [AllowAnonymous]
        public IActionResult Logoff(string returnUrl = null)
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            if (Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);

            return RedirectToAction("Guest", "Home");
        }


        [AllowAnonymous]
        public IActionResult Forbidden()
        {
            return View();
        } 

        [Authorize(Roles = "admin")]
        public IActionResult Users()
        {
            List<Users> list = DBUtl.GetList<Users>("SELECT * FROM Users WHERE User_Type='member' ");
            return View(list);
        }

        [AllowAnonymous]
        public IActionResult VerifyUserID(string emailaddress)
        {
            string select = $"SELECT * FROM Users WHERE User_EmailAddress='{emailaddress}'";
             if (DBUtl.GetTable(select).Rows.Count > 0)
            {
              return Json($"[{emailaddress}] already in use");
            }
            return Json(true);

            
        }

        private bool AuthenticateUser(string emailaddress, string pw,
                                      out ClaimsPrincipal principal)
        {
            principal = null;

            // Compare given userid abd pwd with the database => Aim for authentication
            // TODO L08 Task 1 - Provide Login SELECT Statement
           
            DataTable ds = DBUtl.GetTable(LOGIN_SQL, emailaddress, pw);
            if (ds.Rows.Count == 1) // proves the user (with password) exist in the datebase 
            {
                // this object only stores uid and fullname for new 
                principal =
                   new ClaimsPrincipal(
                      new ClaimsIdentity(
                         new Claim[] {
                        new Claim(ClaimTypes.NameIdentifier, emailaddress),
                        new Claim(ClaimTypes.Name, ds.Rows[0][NAME_COL].ToString()),
                        new Claim(ClaimTypes.Role, ds.Rows[0][ROLE_COL].ToString())
                         }, "Basic"
                         )
                      );
                return true;
            }
            return false;  
        }



    }
}