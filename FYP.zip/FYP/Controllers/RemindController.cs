﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using FYP.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FYP.Controllers
{
    public class RemindController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        private List<Attendance> GetListAttendance()
        {
            // Get a list of all events from the database
            string eventSql = @"SELECT * FROM Attendance
            ";
            List<Attendance> lstEvent = DBUtl.GetList<Attendance>(eventSql);
            return lstEvent;
        }



        public IActionResult List()
        {

            List<Reminder> materials = DBUtl.GetList<Reminder>(
           @"SELECT ReminderDB.Reminder_ID, Attendance.Attendance_ID, Users.User_FirstName, Users.User_EmailAddress, Events.Eventname,CONVERT(DATETIME, Events.Eventdate) As Eventdate, CONVERT(DATETIME,  Events.Eventstarttime) As Eventstarttime, Events.Eventvenue
FROM Users, Attendance, Events, ReminderDB
                                WHERE Attendance.Event_ID= Events.Eventid
                                AND Attendance.User_ID= Users.User_ID
                                AND Attendance.Attendance_ID= ReminderDB.Attendance_ID
                            
                      
                   ");
            return View(materials);



        }
  


        public IActionResult Create()
        {
            ViewData["Attend"] = GetListAttendance();
            return View();
        }

        [HttpPost]
        public IActionResult Create(Reminder rmd)
        {
            if (!ModelState.IsValid)
            {
                ViewData["Genres"] = GetListAttendance();
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("Create");
            }
            else
            {
                // TODO: L13 Task 10 - Secure INSERT statement
                string insert =
                   @"INSERT INTO ReminderDB (Attendance_ID) 
                 VALUES({0})";

                // int result = DBUtl.ExecSQL(insert, newMovie.Title, newMovie.ReleaseDate, newMovie.Price,
                //newMovie.Duration, newMovie.Rating, newMovie.GenreId);  // safe

                if (DBUtl.ExecSQL(insert,  rmd.Attendance_ID) == 1)
                {
                    TempData["Message"] = "Reminder ID Inserted";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
                return RedirectToAction("List");
            }
        }





        [HttpGet]
        public IActionResult Edit(string id)
        {
            // TODO: L13 Task 08 - Show form with values for update
            // To start this TASK, delete 3 lines in this method with "REMOVE THIS LINE"


            // Get the record from the database using the id
            string Sql = @"SELECT ReminderDB.Reminder_ID, Attendance.Attendance_ID, Users.User_FirstName, Users.User_EmailAddress, Events.Eventname,CONVERT(DATETIME, Events.Eventdate) As Eventdate, CONVERT(DATETIME,  Events.Eventstarttime) As Eventstarttime, Events.Eventvenue
FROM Users, Attendance, Events, ReminderDB
                                WHERE Attendance.Event_ID= Events.Eventid
                                AND Attendance.User_ID= Users.User_ID
                                AND Attendance.Attendance_ID = ReminderDB.Attendance_ID 
                                AND ReminderDB.Reminder_ID  = {0}";
            List<Reminder> lstMovie = DBUtl.GetList<Reminder>(Sql, id);

            // If the record is found, pass the model to the View
            if (lstMovie.Count == 1)
            {
               
                return View(lstMovie[0]);
            }
            else
            // Otherwise redirect to the movie list page
            {
                TempData["Message"] = "Reminder not found.";
                TempData["MsgType"] = "warning";
                return RedirectToAction("Edit");
            }


        }

      

        [HttpPost]
       // [Authorize(Roles = "admin")]
        public IActionResult Edit(Reminder movie)
        {
            if (!ModelState.IsValid)
            {
         
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("Edit");
            }

            string template = @"Hi {0},<br/><br/>
                               Just a reminder that you have registered for : <b>{1}</b> 
                               <p> Date : <b>{2}</b> </p>
                               <p> Time : <b>{3}</b> </p>
                               <p> Venue: <b>{4}</b> </p>

                               
                               

                               <br/><br/>CMP Portal";
            string title = "Auto Reminder - CMP Portal";
            string date = String.Format("{0:dd MMM yyyy}", movie.Eventdate);
            string time = String.Format("{0:hh mm ss}", movie.Eventstarttime);

            string message = String.Format(template, movie.User_FirstName, movie.Eventname, date, time, movie.Eventvenue);
            string result;

            if (EmailUtl.SendEmail(movie.User_EmailAddress, title, message, out result))
            {
                TempData["Message"] = "Reminder Sent";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("Edit");
        }

        public IActionResult Delete(int id)
        {
            string select = @"SELECT * FROM ReminderDB 
                              WHERE Reminder_ID ={0}";
            DataTable ds = DBUtl.GetTable(select, id);
            if (ds.Rows.Count != 1)
            {
                TempData["Message"] = "Reminder ID record no longer exists.";
                TempData["MsgType"] = "warning";
            }
            else
            {
                string delete = "DELETE FROM ReminderDB WHERE Reminder_ID ={0}";
                int res = DBUtl.ExecSQL(delete, id);
                if (res == 1)
                {
                    TempData["Message"] = "Reminder ID Deleted";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
            }
            return RedirectToAction("List");
        }

    }
}
