﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FYP.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;
using System.Data;
using Microsoft.AspNetCore.Http;

namespace FYP.Controllers
{
    public class DummyController : Controller
    {
       

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult UserLogin()
        {
            return View();
        }

        [Authorize]
        public IActionResult Logoff(string returnUrl = null)
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            if (Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);
            return RedirectToAction("Users", "Users");
        }

        [AllowAnonymous] // Anyone can access the page
        [HttpGet]
        public IActionResult Login(string returnUrl = null)
        {
            TempData["ReturnUrl"] = returnUrl;
            return View();
        }

        [AllowAnonymous]
        [HttpPost] // previous action will be [HttpGet](MUST WRITE IT)
        public IActionResult Login(UserLogin user)
        {
            if (!AuthenticateUser(user.User_EmailAddress, user.User_Pw,
                                  out ClaimsPrincipal principal))
            {
                ViewData["Message"] = "Incorrect Email Address or Password";
                return View();
            }
            else
            {
                HttpContext.SignInAsync(
                   CookieAuthenticationDefaults.AuthenticationScheme,
                   principal);

                if (TempData["returnUrl"] != null)
                {
                    string returnUrl = TempData["returnUrl"].ToString();
                    if (Url.IsLocalUrl(returnUrl))
                        return Redirect(returnUrl);
                }

                return RedirectToAction("Users", "Users");
            }
        }

        private bool AuthenticateUser(string uid, string pw,
                                      out ClaimsPrincipal principal)
        {
            principal = null;

            // Compare given userid abd pwd with the database => Aim for authentication


            // TODO L08 Task 1 - Provide Login SELECT Statement
            string sql = @"SELECT * FROM Users WHERE User_EmailAddress= '{0}' AND User_Pw = HASHBYTES('SHA1', '{1}')";

            string select = String.Format(sql, uid, pw);
            DataTable ds = DBUtl.GetTable(select);
            if (ds.Rows.Count == 1) // proves the user (with password) exist in the datebase 
            {
                // this object only stores uid and fullname for new 
                principal =
                   new ClaimsPrincipal(
                      new ClaimsIdentity(
                         new Claim[] {
                        new Claim(ClaimTypes.NameIdentifier, uid),
                        new Claim(ClaimTypes.Name, ds.Rows[0]["User_FirstName"].ToString())
                         },
                         CookieAuthenticationDefaults.AuthenticationScheme));
                return true;
            }
            return false; // 
        }

        public IActionResult UsersList()
        {
            string sql = "SELECT User_ID, User_Pw, User_Type, User_FirstName, User_LastName, User_Gender, CONVERT(VARCHAR, User_Date_of_Birth, 106) As User_Date_of_Birth, User_ContactNumber, User_EmailAddress FROM Users";
            DataTable dt = DBUtl.GetTable(sql);
            return View(dt.Rows);
        }

        public IActionResult AddUser()
        {
            return View();
        }

        public IActionResult AddUserPost()
        {
            IFormCollection form = HttpContext.Request.Form;
            string User_Pw = form["User_Pw"].ToString().Trim();
            string User_Type = form["User_Type"].ToString().Trim();
            string User_FirstName = form["User_FirstName"].ToString().Trim();
            string User_LastName = form["User_LastName"].ToString().Trim();
            string User_Gender = form["User_Gender"].ToString().Trim();
            string User_Date_of_Birth = form["User_Date_of_Birth"].ToString().Trim();
            string User_EmailAddress = form["User_EmailAddress"].ToString().Trim();
            string User_ContactNumber = form["User_ContactNumber"].ToString().Trim();
            string sql = @"INSERT INTO Users(User_Pw, User_Type, User_FirstName, User_LastName, User_Gender, User_Date_of_Birth, User_EmailAddress, User_ContactNumber) 
                        VALUES(HASHBYTES('SHA1', '{0}'), '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}')";
            string insert = String.Format(sql, User_Pw, User_Type, User_FirstName, User_LastName, User_Gender, User_Date_of_Birth, User_EmailAddress, User_ContactNumber);
            if (DBUtl.ExecSQL(insert) == 1)
            {
                string template = @"Hi! {0} <br/><br/> Welcome to Cohort Management Portal! <br/><br/> Your userid is <b>{1}</b> and password is <b>{2}</b>.";
                string title = "Registration Successul - Welcome";
                string message = String.Format(template, User_FirstName, User_LastName, User_Pw);
                string result;
                EmailUtl.SendEmail(User_EmailAddress, title, message, out result);
                /* {
                    TempData["Message"] = "User is Successfully Added";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                } */
            }
            return RedirectToAction("UserLogin");
        }
        
        public IActionResult Add_User()
        {
            return View();
        }

        public IActionResult Add_UserPost()
        {
            IFormCollection form = HttpContext.Request.Form;
            string User_Pw = form["User_Pw"].ToString().Trim();
            string User_Type = form["User_Type"].ToString().Trim();
            string User_FirstName = form["User_FirstName"].ToString().Trim();
            string User_LastName = form["User_LastName"].ToString().Trim();
            string User_Gender = form["User_Gender"].ToString().Trim();
            string User_Date_of_Birth = form["User_Date_of_Birth"].ToString().Trim();
            string User_EmailAddress = form["User_EmailAddress"].ToString().Trim();
            string User_ContactNumber = form["User_ContactNumber"].ToString().Trim();
            string sql = @"INSERT INTO Users(User_Pw, User_Type, User_FirstName, User_LastName, User_Gender, User_Date_of_Birth, User_EmailAddress, User_ContactNumber) 
                        VALUES(HASHBYTES('SHA1', '{0}'), '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}')";
            string insert = String.Format(sql, User_Pw, User_Type, User_FirstName, User_LastName, User_Gender, User_Date_of_Birth, User_EmailAddress, User_ContactNumber);
            int res = DBUtl.ExecSQL(insert);
            if (res == 1)
            {
                TempData["Message"] = "User is Successfully Added";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            } 
            return RedirectToAction("UsersList");
        }

        public IActionResult MyAcct(String id)
        {
            string sql = "SELECT User_ID, User_Pw, User_Type, User_FirstName, User_LastName, User_Gender, CONVERT(DATETIME, User_Date_of_Birth) As User_Date_of_Birth, User_ContactNumber, User_EmailAddress FROM Users WHERE User_ID = '{0}'";
            string select = String.Format(sql, id);
            DataTable dt = DBUtl.GetTable(select);
            if (dt.Rows.Count == 1)
            {
                Users user = new Users
                {
                    User_ID = (int)dt.Rows[0]["User_ID"],
                    User_Pw = dt.Rows[0]["User_Pw"].ToString(),
                    User_Type = dt.Rows[0]["User_Type"].ToString(),
                    User_FirstName = dt.Rows[0]["User_FirstName"].ToString(),
                    User_LastName = dt.Rows[0]["User_LastName"].ToString(),
                    User_Gender = dt.Rows[0]["User_Gender"].ToString(),
                    User_Date_of_Birth = (DateTime)dt.Rows[0]["User_Date_of_Birth"],
                    User_EmailAddress = dt.Rows[0]["User_EmailAddress"].ToString(),
                    User_ContactNumber = (int)dt.Rows[0]["User_ContactNumber"]

                };
                return View(user);
            }
            return View();
        }


        public IActionResult MyAcctPost(String id)
        {
            IFormCollection form = HttpContext.Request.Form;

            string User_ID = form["User_ID"].ToString().Trim();
            string User_Pw = form["User_Pw"].ToString().Trim();
            string User_Type = form["User_Type"].ToString().Trim();
            string User_FirstName = form["User_FirstName"].ToString().Trim();
            string User_LastName = form["User_LastName"].ToString().Trim();
            string User_Gender = form["User_Gender"].ToString().Trim();
            string User_Date_of_Birth = form["User_Date_of_Birth"].ToString().Trim();
            string User_EmailAddress = form["User_EmailAddress"].ToString().Trim();
            string User_ContactNumber = form["User_ContactNumber"].ToString().Trim();

            string sql = @"UPDATE Users SET User_Pw = HASHBYTES('SHA1', '{1}'), User_Type = '{2}', User_FirstName = '{3}', User_LastName = '{4}', User_Gender = '{5}', User_Date_of_Birth = '{6}', User_EmailAddress = '{7}', User_ContactNumber = '{8}' WHERE User_ID = '{0}'";
            string update = String.Format(sql, User_ID, User_Pw, User_Type, User_FirstName, User_LastName, User_Gender, User_Date_of_Birth, User_EmailAddress, User_ContactNumber);
            int res = DBUtl.ExecSQL(update);
            if (res == 1)
            {
                TempData["Message"] = "User Profile is Successfully Updated";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("UsersList");
        }

        public IActionResult DeleteUser(String id)
        {
            string sql = "DELETE FROM Users WHERE User_ID = '{0}'";
            string delete = String.Format(sql, id);
            int res = DBUtl.ExecSQL(delete);
            if (res == 1)
            {
                TempData["Message"] = "User Successfully Deleted";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("UsersList");
        }


        public IActionResult UsersList2()
        {
            string sql = "SELECT User_ID, User_Pw, User_FirstName, User_LastName, User_Gender,  CONVERT(DATETIME, User_Date_of_Birth) As User_Date_of_Birth, User_ContactNumber, User_EmailAddress FROM Users";
            DataTable dt = DBUtl.GetTable(sql);
            return View(dt.Rows);
        }


        public IActionResult MyAcct2 (String id)
        {
            string sql = "SELECT User_ID, User_Pw, User_FirstName, User_LastName, User_Gender,  CONVERT(DATETIME, User_Date_of_Birth) As User_Date_of_Birth, User_ContactNumber, User_EmailAddress FROM Users WHERE User_ID = '{0}'";
            string select = String.Format(sql, id);
            DataTable dt = DBUtl.GetTable(select);
            if (dt.Rows.Count == 1)
            {
                Users user = new Users
                {
                    User_ID = (int)dt.Rows[0]["User_ID"],
                    User_Pw = dt.Rows[0]["User_Pw"].ToString(),
                   
                    User_FirstName = dt.Rows[0]["User_FirstName"].ToString(),
                    User_LastName = dt.Rows[0]["User_LastName"].ToString(),
                    User_Gender = dt.Rows[0]["User_Gender"].ToString(),
                    User_Date_of_Birth = (DateTime)dt.Rows[0]["User_Date_of_Birth"],
                    User_EmailAddress = dt.Rows[0]["User_EmailAddress"].ToString(),
                    User_ContactNumber = (int)dt.Rows[0]["User_ContactNumber"]

                };
                return View(user);
            }
            return View();
        }


        public IActionResult MyAcct2Post(String id)
        {
            IFormCollection form = HttpContext.Request.Form;

            string User_ID = form["User_ID"].ToString().Trim();
            string User_Pw = form["User_Pw"].ToString().Trim();
           
            string User_FirstName = form["User_FirstName"].ToString().Trim();
            string User_LastName = form["User_LastName"].ToString().Trim();
            string User_Gender = form["User_Gender"].ToString().Trim();
            string User_Date_of_Birth = form["User_Date_of_Birth"].ToString().Trim();
            string User_EmailAddress = form["User_EmailAddress"].ToString().Trim();
            string User_ContactNumber = form["User_ContactNumber"].ToString().Trim();

            string sql = @"UPDATE Users SET User_Pw = HASHBYTES('SHA1', '{1}'),  User_FirstName = '{2}', User_LastName = '{3}', User_Gender = '{4}', User_Date_of_Birth = '{5}', User_EmailAddress = '{6}', User_ContactNumber = '{7}' WHERE User_ID = '{0}'";
            string update = String.Format(sql, User_ID, User_Pw,  User_FirstName, User_LastName, User_Gender, User_Date_of_Birth, User_EmailAddress, User_ContactNumber);
            int res = DBUtl.ExecSQL(update);
            if (res == 1)
            {
                TempData["Message"] = "User Profile is Successfully Updated";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("UserList2");
        }





    }
}