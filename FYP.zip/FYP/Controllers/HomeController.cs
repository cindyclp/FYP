﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace FYP.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
       
        [AllowAnonymous]
        public IActionResult Dashboard()
        {
            return View("Dashboard");
        }

       
        [AllowAnonymous]
        public IActionResult About()
        {
            return View("About");
        }

        [AllowAnonymous]
        public IActionResult Guest()
        {
            return View("Guest");
        }

    }
}