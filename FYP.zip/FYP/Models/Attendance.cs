﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FYP.Models
{
    public class Attendance
    { 
        public int Attendance_ID { get; set; }
        public string Status_Type { get; set; }
        public int User_ID { get; set; }
        public int Event_ID { get; set; }
    }
}