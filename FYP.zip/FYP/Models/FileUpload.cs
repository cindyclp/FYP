﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FYP.Models
{
   
       public class FileUpload
    {
        public int FileId { get; set; }

        [Required(ErrorMessage = "Please select file")]
        public IFormFile Photo { get; set; }

        public string Picture { get; set; }

        public int Eventid { get; set; }

        public string Eventname { get; set; }

    }

}
