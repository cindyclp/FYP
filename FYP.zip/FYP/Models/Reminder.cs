﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace FYP.Models
{
    public class Reminder 
    {
        public int Reminder_ID { get; set; }

        public string User_EmailAddress { get; set; }

        public int User_ID { get; set; }

        public int Attendance_ID { get; set; }

        public string User_FirstName { get; set; }


        public int Eventid { get; set; }
        public string Eventname { get; set; }

        [DataType(DataType.Date)]
        public DateTime Eventdate { get; set; }

        [DataType(DataType.Time)]
        public DateTime Eventstarttime { get; set; }

        public string Eventvenue { get; set; }




    }
}
