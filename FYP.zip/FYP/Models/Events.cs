﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.Models
{
   public class Events
   {
      public int Eventid { get; set; }
      public string Eventname { get; set; }
      [DataType(DataType.Date)]
      public DateTime Eventdate  { get; set; }
      [DataType(DataType.Time)]
      public DateTime Eventstarttime { get; set; }
      [DataType(DataType.Time)]
      public DateTime Eventendtime { get; set; }
      public string Eventvenue { get; set; }
      public string Eventdescription { get; set; }
    }
}